# ⚔ FALSE GAME

**A gamified self-improvement system built on RPG progression mechanics.**

Dark. Futuristic. Ruthless.

---

## Features

- **XP & Level System** — Level 1 starts at 100 XP, each level doubles the requirement
- **Rank System** — UNEVOLVED → EVOLVER → PHANTOM → DEMI ELITE → ELITE
- **Quest System** — Create, edit, complete, and delete tasks with difficulty tiers
- **Penalty System** — Miss a task and lose XP automatically
- **FALSE GUIDE** — AI assistant powered by Claude (intelligent, strategic, direct)
- **Achievements** — 13 unlockable achievements
- **Stats Tracking** — Streaks, XP history, completion rates, level history
- **Persistent Storage** — All data saved to localStorage, no server needed

---

## Quick Start (Local)

### Prerequisites
- Node.js 18+ installed ([nodejs.org](https://nodejs.org))
- A free Anthropic API key ([console.anthropic.com](https://console.anthropic.com))

### 1. Clone or Download

```bash
# If using git:
git clone https://github.com/YOUR_USERNAME/false-game.git
cd false-game

# Or extract the zip and:
cd false-game
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Set Up Environment Variables

Create a file called `.env.local` in the root of the project:

```bash
# .env.local
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

> **How to get an API key:**
> 1. Go to [console.anthropic.com](https://console.anthropic.com)
> 2. Sign up / log in
> 3. Click "API Keys" → "Create Key"
> 4. Copy the key and paste it above

### 4. Run Locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## Deploy to Vercel (Free)

### Method 1: Vercel CLI (Recommended)

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy from project folder
vercel

# Follow the prompts:
# - Link to existing project? No
# - Project name: false-game
# - Directory: ./
# - Override settings? No
```

Then add your environment variable in Vercel:

```bash
vercel env add ANTHROPIC_API_KEY
# Paste your key when prompted
# Select: Production, Preview, Development

# Re-deploy with env vars
vercel --prod
```

### Method 2: Vercel Dashboard (Easiest for beginners)

1. Push your code to GitHub (see below)
2. Go to [vercel.com](https://vercel.com) → Sign up with GitHub
3. Click **"New Project"** → Import your `false-game` repo
4. Under **Environment Variables**, add:
   - Name: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-your-key-here`
5. Click **Deploy**

Your app will be live at `https://false-game.vercel.app` (or similar).

---

## Upload to GitHub

```bash
# Initialize git repo
git init

# Add all files
git add .

# First commit
git commit -m "Initialize False Game System"

# Create repo on GitHub (github.com → New Repository → name: false-game)
# Then connect and push:
git remote add origin https://github.com/YOUR_USERNAME/false-game.git
git branch -M main
git push -u origin main
```

> ⚠️ **Never commit your `.env.local` file.** It's in `.gitignore` by default.

---

## Project Structure

```
false-game/
├── src/
│   ├── app/
│   │   ├── layout.tsx          # Root layout
│   │   ├── page.tsx            # Main app shell
│   │   └── globals.css         # Global styles
│   ├── components/
│   │   ├── ui/
│   │   │   ├── Nav.tsx         # Bottom navigation
│   │   │   ├── Toast.tsx       # Notification toasts
│   │   │   └── LevelUpOverlay  # Level up screen
│   │   ├── dashboard/
│   │   │   └── DashboardPanel  # Main stats display
│   │   ├── tasks/
│   │   │   ├── TaskCard.tsx    # Individual task
│   │   │   └── TaskForm.tsx    # Create/edit modal
│   │   ├── stats/
│   │   │   └── StatsPanel.tsx  # Statistics view
│   │   ├── achievements/
│   │   │   ├── AchievementsPanel.tsx
│   │   │   └── AchievementUnlock.tsx
│   │   └── ai/
│   │       └── FalseGuide.tsx  # AI chat assistant
│   ├── hooks/
│   │   └── useGameState.ts     # Core game state
│   ├── lib/
│   │   ├── game.ts             # Game logic & formulas
│   │   └── achievements.ts     # Achievement definitions
│   └── types/
│       └── index.ts            # TypeScript types
├── package.json
├── tailwind.config.js
├── next.config.js
└── vercel.json
```

---

## XP & Level Formula

```
XP Required = 100 × 2^(Level - 1)

Level 1  = 100 XP
Level 2  = 200 XP
Level 3  = 400 XP
Level 4  = 800 XP
Level 5  = 1,600 XP
Level 10 = 51,200 XP
```

## Rank Table

| Levels | Rank       |
|--------|------------|
| 1–3    | UNEVOLVED  |
| 4–6    | EVOLVER    |
| 7–8    | PHANTOM    |
| 9      | DEMI ELITE |
| 10+    | ELITE      |

## Difficulty & XP

| Difficulty | XP Reward | XP Penalty |
|------------|-----------|------------|
| Easy       | +25 XP    | −5 XP      |
| Medium     | +50 XP    | −15 XP     |
| Hard       | +100 XP   | −30 XP     |
| Extreme    | +200 XP   | −75 XP     |

---

## Troubleshooting

**FALSE GUIDE not responding?**
- Check your `ANTHROPIC_API_KEY` in `.env.local`
- Make sure you have API credits at [console.anthropic.com](https://console.anthropic.com)

**Data not saving?**
- Data is in localStorage — don't use private/incognito mode
- Don't clear browser storage

**Build errors?**
- Run `npm install` again
- Make sure Node.js 18+ is installed: `node --version`

---

*False Game System v1.0 — Evolve or remain.*
