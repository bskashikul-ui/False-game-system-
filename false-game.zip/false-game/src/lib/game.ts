import type { GameStats, Rank, Difficulty, Task } from "@/types";

export function getXPRequired(level: number): number {
  return Math.floor(100 * Math.pow(2, level - 1));
}

export function getLevelFromTotalXP(totalXP: number): { level: number; currentXP: number } {
  let level = 1;
  let remaining = totalXP;
  while (remaining >= getXPRequired(level)) {
    remaining -= getXPRequired(level);
    level++;
  }
  return { level, currentXP: remaining };
}

export function getRank(level: number): Rank {
  if (level <= 3) return "UNEVOLVED";
  if (level <= 6) return "EVOLVER";
  if (level <= 8) return "PHANTOM";
  if (level === 9) return "DEMI ELITE";
  return "ELITE";
}

export function getRankColor(rank: Rank): string {
  switch (rank) {
    case "UNEVOLVED": return "text-gray-400";
    case "EVOLVER": return "text-orange-400";
    case "PHANTOM": return "text-purple-400";
    case "DEMI ELITE": return "text-yellow-400";
    case "ELITE": return "text-red-400";
  }
}

export function getRankGlow(rank: Rank): string {
  switch (rank) {
    case "UNEVOLVED": return "shadow-[0_0_10px_rgba(156,163,175,0.3)]";
    case "EVOLVER": return "shadow-[0_0_10px_rgba(251,146,60,0.4)]";
    case "PHANTOM": return "shadow-[0_0_10px_rgba(192,132,252,0.4)]";
    case "DEMI ELITE": return "shadow-[0_0_10px_rgba(250,204,21,0.5)]";
    case "ELITE": return "shadow-[0_0_20px_rgba(239,68,68,0.6)]";
  }
}

export function getDifficultyXP(difficulty: Difficulty): number {
  switch (difficulty) {
    case "Easy": return 25;
    case "Medium": return 50;
    case "Hard": return 100;
    case "Extreme": return 200;
  }
}

export function getDifficultyPenalty(difficulty: Difficulty): number {
  switch (difficulty) {
    case "Easy": return 5;
    case "Medium": return 15;
    case "Hard": return 30;
    case "Extreme": return 75;
  }
}

export function getDifficultyColor(difficulty: Difficulty): string {
  switch (difficulty) {
    case "Easy": return "text-green-400 border-green-800";
    case "Medium": return "text-yellow-400 border-yellow-800";
    case "Hard": return "text-orange-400 border-orange-800";
    case "Extreme": return "text-red-400 border-red-800";
  }
}

export function isTaskExpired(task: Task): boolean {
  if (task.completed || task.penaltyApplied) return false;
  return new Date() > new Date(task.dueTime);
}

export function formatDate(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

export function formatDateTime(date: string | Date): string {
  const d = new Date(date);
  return d.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function getTimeRemaining(dueTime: string): string {
  const now = new Date();
  const due = new Date(dueTime);
  const diff = due.getTime() - now.getTime();

  if (diff <= 0) return "EXPIRED";

  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

  if (hours > 24) {
    const days = Math.floor(hours / 24);
    return `${days}d ${hours % 24}h`;
  }
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
}

export function getDefaultStats(): GameStats {
  return {
    level: 1,
    currentXP: 0,
    totalXPEarned: 0,
    totalXPLost: 0,
    currentStreak: 0,
    longestStreak: 0,
    totalTasksCompleted: 0,
    totalTasksMissed: 0,
    lastActiveDate: new Date().toISOString().split("T")[0],
    levelHistory: [{ level: 1, date: new Date().toISOString() }],
    unlockedAchievements: [],
  };
}
