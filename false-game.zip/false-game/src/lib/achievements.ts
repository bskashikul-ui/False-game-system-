import type { Achievement, GameStats } from "@/types";

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: "first_quest",
    title: "FIRST QUEST",
    description: "Complete your first task",
    icon: "⚔️",
    condition: (s: GameStats) => s.totalTasksCompleted >= 1,
  },
  {
    id: "first_level_up",
    title: "ASCENDING",
    description: "Reach Level 2",
    icon: "↑",
    condition: (s: GameStats) => s.level >= 2,
  },
  {
    id: "streak_3",
    title: "CONSISTENT",
    description: "Maintain a 3-day streak",
    icon: "🔥",
    condition: (s: GameStats) => s.longestStreak >= 3,
  },
  {
    id: "streak_7",
    title: "7-DAY WARRIOR",
    description: "Maintain a 7-day streak",
    icon: "⚡",
    condition: (s: GameStats) => s.longestStreak >= 7,
  },
  {
    id: "streak_30",
    title: "30-DAY PHANTOM",
    description: "Maintain a 30-day streak",
    icon: "👁",
    condition: (s: GameStats) => s.longestStreak >= 30,
  },
  {
    id: "tasks_10",
    title: "HUNTER",
    description: "Complete 10 tasks",
    icon: "🎯",
    condition: (s: GameStats) => s.totalTasksCompleted >= 10,
  },
  {
    id: "tasks_50",
    title: "VETERAN",
    description: "Complete 50 tasks",
    icon: "🏆",
    condition: (s: GameStats) => s.totalTasksCompleted >= 50,
  },
  {
    id: "tasks_100",
    title: "CENTURION",
    description: "Complete 100 tasks",
    icon: "💀",
    condition: (s: GameStats) => s.totalTasksCompleted >= 100,
  },
  {
    id: "rank_evolver",
    title: "EVOLVER",
    description: "Reach the EVOLVER rank (Level 4)",
    icon: "◆",
    condition: (s: GameStats) => s.level >= 4,
  },
  {
    id: "rank_phantom",
    title: "PHANTOM",
    description: "Reach the PHANTOM rank (Level 7)",
    icon: "◈",
    condition: (s: GameStats) => s.level >= 7,
  },
  {
    id: "rank_elite",
    title: "ELITE STATUS",
    description: "Reach the ELITE rank (Level 10)",
    icon: "★",
    condition: (s: GameStats) => s.level >= 10,
  },
  {
    id: "xp_1000",
    title: "POWER SURGE",
    description: "Earn 1,000 total XP",
    icon: "⚡",
    condition: (s: GameStats) => s.totalXPEarned >= 1000,
  },
  {
    id: "xp_10000",
    title: "TRANSCENDENT",
    description: "Earn 10,000 total XP",
    icon: "∞",
    condition: (s: GameStats) => s.totalXPEarned >= 10000,
  },
];

export function checkNewAchievements(stats: GameStats): string[] {
  const newUnlocks: string[] = [];
  for (const achievement of ACHIEVEMENTS) {
    if (!stats.unlockedAchievements.includes(achievement.id) && achievement.condition(stats)) {
      newUnlocks.push(achievement.id);
    }
  }
  return newUnlocks;
}
