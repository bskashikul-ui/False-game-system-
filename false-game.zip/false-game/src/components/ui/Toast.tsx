"use client";
import { useEffect, useState } from "react";

interface Toast {
  id: string;
  message: string;
  type: "xp" | "levelup" | "achievement" | "penalty" | "info";
  exiting?: boolean;
}

let toastQueue: ((t: Toast) => void)[] = [];
export function showToast(message: string, type: Toast["type"] = "info") {
  const toast: Toast = { id: crypto.randomUUID(), message, type };
  toastQueue.forEach((fn) => fn(toast));
}

export function ToastContainer() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    const fn = (t: Toast) => {
      setToasts((prev) => [...prev, t]);
      setTimeout(() => {
        setToasts((prev) => prev.map((x) => x.id === t.id ? { ...x, exiting: true } : x));
        setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== t.id)), 300);
      }, 3500);
    };
    toastQueue.push(fn);
    return () => { toastQueue = toastQueue.filter((f) => f !== fn); };
  }, []);

  if (toasts.length === 0) return null;

  const colors: Record<Toast["type"], string> = {
    xp: "border-green-700 bg-[#0a1a0a]",
    levelup: "border-red-500 bg-[#1a0a0a] shadow-[0_0_20px_rgba(239,68,68,0.5)]",
    achievement: "border-yellow-600 bg-[#1a1500]",
    penalty: "border-red-900 bg-[#120a0a]",
    info: "border-gray-700 bg-[#111111]",
  };

  const icons: Record<Toast["type"], string> = {
    xp: "⚡",
    levelup: "▲",
    achievement: "★",
    penalty: "▼",
    info: "◆",
  };

  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 max-w-xs w-full">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`${colors[t.type]} border px-4 py-3 rounded text-sm font-mono ${t.exiting ? "toast-exit" : "toast-enter"}`}
        >
          <span className="mr-2">{icons[t.type]}</span>
          {t.message}
        </div>
      ))}
    </div>
  );
}
