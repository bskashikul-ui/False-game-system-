"use client";
import { useEffect, useState, useRef } from "react";
import { getRank, getRankColor } from "@/lib/game";

interface Props {
  level: number;
  prevLevel: number;
  onDone: () => void;
}

export function LevelUpOverlay({ level, prevLevel, onDone }: Props) {
  const [phase, setPhase] = useState<"in" | "hold" | "out">("in");
  const called = useRef(false);

  useEffect(() => {
    if (called.current) return;
    called.current = true;
    const t1 = setTimeout(() => setPhase("hold"), 300);
    const t2 = setTimeout(() => setPhase("out"), 2800);
    const t3 = setTimeout(onDone, 3200);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onDone]);

  const rank = getRank(level);

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center transition-opacity duration-300 ${
        phase === "out" ? "opacity-0" : "opacity-100"
      }`}
      style={{ background: "rgba(0,0,0,0.92)" }}
    >
      <div className="text-center">
        <p className="text-xs text-red-600 font-mono uppercase tracking-widest mb-4 animate-pulse">
          ▲ LEVEL UP
        </p>
        <div className="text-8xl font-black text-white mb-2" style={{ textShadow: "0 0 30px rgba(239,68,68,0.8)" }}>
          {level}
        </div>
        <p className={`text-2xl font-black tracking-widest ${getRankColor(rank)}`}>{rank}</p>
        <div className="mt-6 h-px w-32 mx-auto bg-red-600" style={{ boxShadow: "0 0 10px rgba(239,68,68,0.8)" }} />
      </div>
    </div>
  );
}
