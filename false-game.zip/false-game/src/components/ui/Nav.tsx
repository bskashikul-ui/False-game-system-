"use client";

type Tab = "dashboard" | "tasks" | "stats" | "achievements" | "guide";

interface Props {
  active: Tab;
  onChange: (tab: Tab) => void;
}

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "dashboard", label: "Status", icon: "◉" },
  { id: "tasks", label: "Quests", icon: "◈" },
  { id: "stats", label: "Stats", icon: "▲" },
  { id: "achievements", label: "Feats", icon: "★" },
  { id: "guide", label: "Guide", icon: "◆" },
];

export function Nav({ active, onChange }: Props) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-[#0d0d0d] border-t border-[#1f1f1f]">
      <div className="max-w-2xl mx-auto flex">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            className={`flex-1 flex flex-col items-center py-3 gap-0.5 transition-all ${
              active === tab.id
                ? "text-red-400"
                : "text-gray-600 hover:text-gray-400"
            }`}
          >
            <span className={`text-base ${active === tab.id ? "text-red-400" : ""}`}>{tab.icon}</span>
            <span className="text-[10px] font-mono uppercase tracking-wider">{tab.label}</span>
            {active === tab.id && (
              <div className="absolute bottom-0 h-0.5 w-8 bg-red-500" style={{ boxShadow: "0 0 6px rgba(239,68,68,0.8)" }} />
            )}
          </button>
        ))}
      </div>
    </nav>
  );
}
