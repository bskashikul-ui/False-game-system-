"use client";
import { getRank, getRankColor, getRankGlow, getXPRequired } from "@/lib/game";
import type { GameStats } from "@/types";

interface Props {
  stats: GameStats;
  activeTasks: number;
  completedTasks: number;
}

export function DashboardPanel({ stats, activeTasks, completedTasks }: Props) {
  const rank = getRank(stats.level);
  const xpRequired = getXPRequired(stats.level);
  const progress = Math.min(100, (stats.currentXP / xpRequired) * 100);

  return (
    <div className="space-y-4">
      {/* Level + Rank Hero */}
      <div className={`panel-red p-6 relative overflow-hidden ${getRankGlow(rank)}`}>
        {/* Decorative corner */}
        <div className="absolute top-0 right-0 w-16 h-16 border-t-2 border-r-2 border-red-600 opacity-40" />
        <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-red-600 opacity-20" />

        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-gray-500 uppercase tracking-widest font-mono mb-1">False Game System</p>
            <div className="flex items-baseline gap-3">
              <span className="text-6xl font-black text-white">{stats.level}</span>
              <span className="text-gray-500 text-sm font-mono">LEVEL</span>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-500 uppercase tracking-widest font-mono mb-1">Rank</p>
            <p className={`text-xl font-black tracking-widest ${getRankColor(rank)} ${rank === "ELITE" ? "rank-elite" : ""}`}>
              {rank}
            </p>
          </div>
        </div>

        {/* XP Bar */}
        <div className="mt-5">
          <div className="flex justify-between items-center mb-1">
            <span className="text-xs font-mono text-gray-400">XP</span>
            <span className="text-xs font-mono text-gray-400">
              {stats.currentXP.toLocaleString()} / {xpRequired.toLocaleString()}
            </span>
          </div>
          <div className="h-2 bg-[#1a1a1a] rounded-full overflow-hidden">
            <div
              className="h-full bg-red-500 rounded-full transition-all duration-700"
              style={{
                width: `${progress}%`,
                boxShadow: "0 0 8px rgba(239,68,68,0.6)",
              }}
            />
          </div>
          <p className="text-right text-xs text-gray-600 mt-1 font-mono">
            {xpRequired - stats.currentXP} XP to next level
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-3">
        <StatCard label="Daily Streak" value={`${stats.currentStreak}d`} icon="🔥" accent />
        <StatCard label="Longest Streak" value={`${stats.longestStreak}d`} icon="⚡" />
        <StatCard label="Total XP Earned" value={stats.totalXPEarned.toLocaleString()} icon="↑" color="text-green-400" />
        <StatCard label="XP Lost" value={stats.totalXPLost.toLocaleString()} icon="↓" color="text-red-400" />
        <StatCard label="Active Tasks" value={activeTasks} icon="◉" />
        <StatCard label="Completed" value={completedTasks} icon="✓" color="text-green-400" />
      </div>

      {/* Level Progression Preview */}
      <div className="panel p-4">
        <p className="text-xs text-gray-500 uppercase tracking-widest font-mono mb-3">Next Ranks</p>
        <div className="space-y-2">
          {[
            { level: 4, name: "EVOLVER", color: "text-orange-400" },
            { level: 7, name: "PHANTOM", color: "text-purple-400" },
            { level: 9, name: "DEMI ELITE", color: "text-yellow-400" },
            { level: 10, name: "ELITE", color: "text-red-400" },
          ]
            .filter((r) => r.level > stats.level)
            .slice(0, 2)
            .map((r) => (
              <div key={r.name} className="flex justify-between items-center text-sm">
                <span className={`font-mono font-bold ${r.color}`}>{r.name}</span>
                <span className="text-gray-500 font-mono text-xs">Level {r.level}</span>
              </div>
            ))}
          {stats.level >= 10 && (
            <p className="text-red-400 font-mono text-sm font-bold">★ MAXIMUM RANK ACHIEVED ★</p>
          )}
        </div>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  icon,
  accent,
  color,
}: {
  label: string;
  value: string | number;
  icon: string;
  accent?: boolean;
  color?: string;
}) {
  return (
    <div className={`panel p-3 ${accent ? "border-red-900" : ""}`}>
      <div className="flex items-center justify-between mb-1">
        <span className="text-lg">{icon}</span>
        <span className={`text-xl font-black font-mono ${color || "text-white"}`}>
          {value}
        </span>
      </div>
      <p className="text-xs text-gray-500 uppercase tracking-wider">{label}</p>
    </div>
  );
}
