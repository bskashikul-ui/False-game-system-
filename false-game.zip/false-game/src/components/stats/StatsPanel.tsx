"use client";
import type { GameStats, Task } from "@/types";
import { formatDate } from "@/lib/game";

interface Props {
  stats: GameStats;
  tasks: Task[];
}

export function StatsPanel({ stats, tasks }: Props) {
  const completionRate =
    stats.totalTasksCompleted + stats.totalTasksMissed > 0
      ? Math.round((stats.totalTasksCompleted / (stats.totalTasksCompleted + stats.totalTasksMissed)) * 100)
      : 0;

  const recentCompleted = tasks
    .filter((t) => t.completed && t.completedAt)
    .sort((a, b) => new Date(b.completedAt!).getTime() - new Date(a.completedAt!).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-4">
      {/* Overview grid */}
      <div className="grid grid-cols-2 gap-3">
        <BigStat label="Tasks Completed" value={stats.totalTasksCompleted} color="text-green-400" />
        <BigStat label="Tasks Missed" value={stats.totalTasksMissed} color="text-red-400" />
        <BigStat label="Total XP Earned" value={stats.totalXPEarned.toLocaleString()} color="text-white" />
        <BigStat label="Total XP Lost" value={stats.totalXPLost.toLocaleString()} color="text-red-600" />
        <BigStat label="Completion Rate" value={`${completionRate}%`} color={completionRate >= 70 ? "text-green-400" : "text-orange-400"} />
        <BigStat label="Longest Streak" value={`${stats.longestStreak}d`} color="text-yellow-400" />
      </div>

      {/* XP Balance */}
      <div className="panel p-4">
        <p className="text-xs text-gray-500 uppercase tracking-widest font-mono mb-3">XP Balance</p>
        <div className="relative h-2 bg-[#1a1a1a] rounded-full overflow-hidden">
          <div
            className="absolute left-0 top-0 h-full bg-green-600 rounded-full"
            style={{ width: `${stats.totalXPEarned > 0 ? Math.min(100, (stats.totalXPEarned / (stats.totalXPEarned + stats.totalXPLost)) * 100) : 0}%` }}
          />
        </div>
        <div className="flex justify-between text-xs font-mono mt-1">
          <span className="text-green-500">+{stats.totalXPEarned} earned</span>
          <span className="text-red-600">−{stats.totalXPLost} lost</span>
        </div>
      </div>

      {/* Level History */}
      {stats.levelHistory.length > 1 && (
        <div className="panel p-4">
          <p className="text-xs text-gray-500 uppercase tracking-widest font-mono mb-3">Level History</p>
          <div className="space-y-1 max-h-48 overflow-y-auto">
            {stats.levelHistory.slice(1).reverse().map((entry, i) => (
              <div key={i} className="flex justify-between text-xs font-mono">
                <span className="text-red-400">Level {entry.level}</span>
                <span className="text-gray-600">{formatDate(entry.date)}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent completed tasks */}
      {recentCompleted.length > 0 && (
        <div className="panel p-4">
          <p className="text-xs text-gray-500 uppercase tracking-widest font-mono mb-3">Recent Completions</p>
          <div className="space-y-2">
            {recentCompleted.map((t) => (
              <div key={t.id} className="flex justify-between items-center text-xs font-mono">
                <span className="text-gray-300 truncate mr-2">{t.title}</span>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-green-500">+{t.xpReward} XP</span>
                  <span className="text-gray-600">{formatDate(t.completedAt!)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function BigStat({ label, value, color }: { label: string; value: string | number; color: string }) {
  return (
    <div className="panel p-4">
      <p className={`text-2xl font-black font-mono ${color}`}>{value}</p>
      <p className="text-xs text-gray-500 uppercase tracking-wider mt-1">{label}</p>
    </div>
  );
}
