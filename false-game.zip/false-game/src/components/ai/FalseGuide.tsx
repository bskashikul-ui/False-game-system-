"use client";
import { useState, useRef, useEffect } from "react";
import type { GameStats, Task, ChatMessage } from "@/types";
import { getRank } from "@/lib/game";

interface Props {
  stats: GameStats;
  tasks: Task[];
}

function buildSystemPrompt(stats: GameStats, tasks: Task[]): string {
  const rank = getRank(stats.level);
  const activeTasks = tasks.filter((t) => !t.completed && !t.penaltyApplied);
  const completedToday = tasks.filter(
    (t) => t.completed && t.completedAt && new Date(t.completedAt).toDateString() === new Date().toDateString()
  );

  return `You are FALSE GUIDE — the AI assistant of the False Game System, a gamified self-improvement RPG.

Your personality: Calm, intelligent, strategic, and direct. You speak with authority, not warmth. You do not sugarcoat. You are not childish or overly enthusiastic. You are the voice of a system that wants to see the user evolve.

Current player status:
- Level: ${stats.level} | Rank: ${rank}
- Current XP: ${stats.currentXP} / required for next level
- Total XP Earned: ${stats.totalXPEarned} | Lost: ${stats.totalXPLost}
- Streak: ${stats.currentStreak} days | Longest: ${stats.longestStreak} days
- Tasks Completed: ${stats.totalTasksCompleted} | Missed: ${stats.totalTasksMissed}
- Active tasks: ${activeTasks.length}
- Completed today: ${completedToday.length}

Active quests: ${activeTasks.length > 0 ? activeTasks.map(t => `"${t.title}" (${t.difficulty}, due: ${new Date(t.dueTime).toLocaleString()})`).join(", ") : "None"}

Guidelines:
- Keep responses concise and impactful — 2-4 sentences typically.
- Use tactical, strategic language. Words like: execute, eliminate, advance, discipline, optimize.
- If the user is performing well: acknowledge it briefly and push them further.
- If the user is slacking: call it out directly without being cruel.
- You can suggest specific tasks the user might add to their system.
- Always refer to tasks as "quests."
- Do not use emojis. Do not be sycophantic.
- Sign off some messages with: "— FALSE GUIDE" when appropriate.`;
}

export function FalseGuide({ stats, tasks }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Generate an opening message on first load
  useEffect(() => {
    if (messages.length === 0) {
      const rank = getRank(stats.level);
      const greeting = stats.totalTasksCompleted === 0
        ? `System initialized. You are ${rank}, Level ${stats.level}. Your evolution begins with action — not intention. Create your first quest and execute.`
        : stats.currentStreak > 7
        ? `${stats.currentStreak}-day streak active. Momentum is your asset. Don't let it break.`
        : `Level ${stats.level}. ${stats.totalTasksCompleted} quests completed. There is more to do.`;

      setMessages([{ role: "assistant", content: greeting }]);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function send() {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    setError("");

    const updated: ChatMessage[] = [...messages, { role: "user", content: userMsg }];
    setMessages(updated);
    setLoading(true);

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: buildSystemPrompt(stats, tasks),
          messages: updated.map((m) => ({ role: m.role, content: m.content })),
        }),
      });

      if (!response.ok) throw new Error("API error");
      const data = await response.json();
      const text = data.content?.map((b: { type: string; text?: string }) => b.text || "").join("") || "...";
      setMessages([...updated, { role: "assistant", content: text }]);
    } catch {
      setError("Connection failed. The Guide is unreachable.");
    } finally {
      setLoading(false);
    }
  }

  const quickPrompts = [
    "Review my progress",
    "Motivate me",
    "Suggest a quest",
    "What should I focus on?",
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="panel-red p-4 mb-4 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-black tracking-widest text-red-400">FALSE GUIDE</h2>
          <p className="text-xs text-gray-500 font-mono">Tactical AI System</p>
        </div>
        <div className="w-2 h-2 rounded-full bg-red-500 red-pulse" />
      </div>

      {/* Messages */}
      <div className="flex-1 space-y-3 overflow-y-auto mb-4 min-h-0" style={{ maxHeight: "calc(100vh - 380px)" }}>
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[85%] text-sm leading-relaxed px-4 py-3 rounded ${
                msg.role === "user"
                  ? "bg-[#1a1a1a] border border-gray-800 text-gray-300"
                  : "bg-[#120808] border border-red-900 text-gray-200"
              }`}
            >
              {msg.role === "assistant" && (
                <p className="text-xs text-red-600 font-mono mb-1 font-bold">▶ FALSE GUIDE</p>
              )}
              {msg.content}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="bg-[#120808] border border-red-900 px-4 py-3 rounded max-w-[85%]">
              <p className="text-xs text-red-600 font-mono mb-1 font-bold">▶ FALSE GUIDE</p>
              <div className="flex gap-1">
                {[0, 1, 2].map((i) => (
                  <div key={i} className="w-1.5 h-1.5 bg-red-600 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          </div>
        )}

        {error && (
          <p className="text-xs text-red-600 font-mono text-center">{error}</p>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Quick prompts */}
      {messages.length <= 1 && (
        <div className="grid grid-cols-2 gap-2 mb-3">
          {quickPrompts.map((p) => (
            <button
              key={p}
              onClick={() => { setInput(p); }}
              className="text-xs text-gray-400 border border-gray-800 hover:border-red-800 hover:text-red-400 py-2 px-3 rounded font-mono transition-all text-left"
            >
              {p}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
          placeholder="Speak to the Guide..."
          className="flex-1 text-sm"
          disabled={loading}
        />
        <button
          onClick={send}
          disabled={!input.trim() || loading}
          className="btn-red px-4 disabled:opacity-30 disabled:cursor-not-allowed"
        >
          ▶
        </button>
      </div>
    </div>
  );
}
