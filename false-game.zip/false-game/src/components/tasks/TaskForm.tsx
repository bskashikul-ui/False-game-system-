"use client";
import { useState, useEffect } from "react";
import type { Task, Difficulty } from "@/types";
import { getDifficultyXP, getDifficultyPenalty } from "@/lib/game";

interface Props {
  task?: Task | null;
  onSave: (data: Omit<Task, "id" | "createdAt" | "completed">) => void;
  onClose: () => void;
}

const DIFFICULTIES: Difficulty[] = ["Easy", "Medium", "Hard", "Extreme"];

function defaultDue() {
  const d = new Date();
  d.setHours(d.getHours() + 24);
  return d.toISOString().slice(0, 16);
}

export function TaskForm({ task, onSave, onClose }: Props) {
  const [title, setTitle] = useState(task?.title || "");
  const [description, setDescription] = useState(task?.description || "");
  const [difficulty, setDifficulty] = useState<Difficulty>(task?.difficulty || "Medium");
  const [dueTime, setDueTime] = useState(
    task?.dueTime ? new Date(task.dueTime).toISOString().slice(0, 16) : defaultDue()
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const handleSubmit = () => {
    if (!title.trim()) return;
    onSave({
      title: title.trim(),
      description: description.trim(),
      difficulty,
      dueTime: new Date(dueTime).toISOString(),
      xpReward: getDifficultyXP(difficulty),
    });
    onClose();
  };

  const diffColors: Record<Difficulty, string> = {
    Easy: "border-green-700 text-green-400",
    Medium: "border-yellow-700 text-yellow-400",
    Hard: "border-orange-700 text-orange-400",
    Extreme: "border-red-700 text-red-400",
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
      <div
        className="relative panel-red p-6 w-full max-w-md animate-slide-in"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-black uppercase tracking-widest text-red-400">
            {task ? "◈ EDIT QUEST" : "◈ NEW QUEST"}
          </h2>
          <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors text-xl">✕</button>
        </div>

        <div className="space-y-4">
          {/* Title */}
          <div>
            <label className="text-xs text-gray-500 uppercase tracking-widest font-mono block mb-1">Quest Title *</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter quest name..."
              autoFocus
            />
          </div>

          {/* Description */}
          <div>
            <label className="text-xs text-gray-500 uppercase tracking-widest font-mono block mb-1">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Optional details..."
              rows={2}
              className="resize-none"
            />
          </div>

          {/* Difficulty */}
          <div>
            <label className="text-xs text-gray-500 uppercase tracking-widest font-mono block mb-2">Difficulty</label>
            <div className="grid grid-cols-4 gap-2">
              {DIFFICULTIES.map((d) => (
                <button
                  key={d}
                  onClick={() => setDifficulty(d)}
                  className={`border py-2 text-xs font-mono font-bold rounded transition-all ${
                    difficulty === d
                      ? diffColors[d] + " bg-white/5"
                      : "border-gray-800 text-gray-600 hover:border-gray-600"
                  }`}
                >
                  {d.toUpperCase()}
                </button>
              ))}
            </div>
            <div className="flex justify-between mt-2 text-xs font-mono">
              <span className="text-green-500">+{getDifficultyXP(difficulty)} XP on complete</span>
              <span className="text-red-700">−{getDifficultyPenalty(difficulty)} XP if missed</span>
            </div>
          </div>

          {/* Due Time */}
          <div>
            <label className="text-xs text-gray-500 uppercase tracking-widest font-mono block mb-1">Due Date & Time</label>
            <input
              type="datetime-local"
              value={dueTime}
              onChange={(e) => setDueTime(e.target.value)}
              className="text-sm"
            />
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 mt-6">
          <button onClick={onClose} className="btn-ghost flex-1">Cancel</button>
          <button onClick={handleSubmit} className="btn-red flex-1" disabled={!title.trim()}>
            {task ? "UPDATE" : "CREATE QUEST"}
          </button>
        </div>
      </div>
    </div>
  );
}
