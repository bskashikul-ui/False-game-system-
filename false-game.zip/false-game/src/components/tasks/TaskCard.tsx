"use client";
import { useState } from "react";
import type { Task } from "@/types";
import { getDifficultyColor, getDifficultyXP, getDifficultyPenalty, getTimeRemaining, formatDateTime } from "@/lib/game";

interface Props {
  task: Task;
  onComplete: (id: string) => void;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
}

export function TaskCard({ task, onComplete, onEdit, onDelete }: Props) {
  const [confirming, setConfirming] = useState(false);
  const expired = !task.completed && !task.penaltyApplied && new Date() > new Date(task.dueTime);
  const timeLeft = getTimeRemaining(task.dueTime);
  const isUrgent = !task.completed && !expired && !task.penaltyApplied &&
    new Date(task.dueTime).getTime() - Date.now() < 2 * 60 * 60 * 1000;

  const statusBorder = task.completed
    ? "border-green-900"
    : expired || task.penaltyApplied
    ? "border-red-900 opacity-60"
    : isUrgent
    ? "border-orange-800"
    : "border-[#1f1f1f]";

  return (
    <div className={`panel p-4 ${statusBorder} transition-all duration-200 hover:border-gray-700`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          {/* Title + status */}
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <h3 className={`font-bold text-sm truncate ${task.completed ? "line-through text-gray-500" : "text-white"}`}>
              {task.title}
            </h3>
            {task.completed && (
              <span className="text-xs text-green-400 font-mono">✓ DONE</span>
            )}
            {(expired || task.penaltyApplied) && (
              <span className="text-xs text-red-500 font-mono">✗ FAILED</span>
            )}
            {isUrgent && !task.completed && (
              <span className="text-xs text-orange-400 font-mono animate-pulse">⚠ URGENT</span>
            )}
          </div>

          {task.description && (
            <p className="text-xs text-gray-500 mb-2 line-clamp-2">{task.description}</p>
          )}

          <div className="flex items-center gap-3 flex-wrap">
            {/* Difficulty */}
            <span className={`text-xs font-mono font-bold border px-2 py-0.5 rounded ${getDifficultyColor(task.difficulty)}`}>
              {task.difficulty.toUpperCase()}
            </span>

            {/* XP */}
            <span className="text-xs font-mono text-green-400">+{getDifficultyXP(task.difficulty)} XP</span>

            {/* Penalty */}
            {!task.completed && (
              <span className="text-xs font-mono text-red-600">
                −{getDifficultyPenalty(task.difficulty)} if missed
              </span>
            )}

            {/* Time */}
            <span className={`text-xs font-mono ml-auto ${expired || task.penaltyApplied ? "text-red-600" : isUrgent ? "text-orange-400" : "text-gray-500"}`}>
              {task.completed
                ? `Completed ${formatDateTime(task.completedAt!)}`
                : expired || task.penaltyApplied
                ? `Expired ${formatDateTime(task.dueTime)}`
                : timeLeft}
            </span>
          </div>
        </div>

        {/* Actions */}
        {!task.completed && !task.penaltyApplied && (
          <div className="flex flex-col gap-1 shrink-0">
            {!expired && (
              <button
                onClick={() => onComplete(task.id)}
                className="btn-red py-1 px-3 text-xs"
              >
                ✓ DONE
              </button>
            )}
            <button
              onClick={() => onEdit(task)}
              className="btn-ghost py-1 px-3 text-xs"
            >
              EDIT
            </button>
            {confirming ? (
              <div className="flex gap-1">
                <button onClick={() => onDelete(task.id)} className="text-xs text-red-500 hover:text-red-400 font-mono">YES</button>
                <button onClick={() => setConfirming(false)} className="text-xs text-gray-500 hover:text-gray-400 font-mono">NO</button>
              </div>
            ) : (
              <button onClick={() => setConfirming(true)} className="text-xs text-gray-600 hover:text-red-500 font-mono transition-colors">DELETE</button>
            )}
          </div>
        )}

        {(task.completed || task.penaltyApplied) && (
          <button onClick={() => setConfirming(true)} className="shrink-0">
            {confirming ? (
              <div className="flex flex-col gap-1">
                <button onClick={() => onDelete(task.id)} className="text-xs text-red-500 font-mono">✗</button>
                <button onClick={() => setConfirming(false)} className="text-xs text-gray-500 font-mono">○</button>
              </div>
            ) : (
              <span className="text-xs text-gray-700 hover:text-gray-500 font-mono transition-colors">✕</span>
            )}
          </button>
        )}
      </div>
    </div>
  );
}
