"use client";
import { useEffect, useState } from "react";
import { ACHIEVEMENTS } from "@/lib/achievements";

interface Props {
  achievementIds: string[];
  onDismiss: () => void;
}

export function AchievementUnlock({ achievementIds, onDismiss }: Props) {
  const [index, setIndex] = useState(0);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    if (achievementIds.length === 0) return;
    const t = setTimeout(() => {
      if (index < achievementIds.length - 1) {
        setIndex((i) => i + 1);
      } else {
        setVisible(false);
        setTimeout(onDismiss, 300);
      }
    }, 2500);
    return () => clearTimeout(t);
  }, [index, achievementIds.length, onDismiss]);

  if (!visible || achievementIds.length === 0) return null;

  const achievement = ACHIEVEMENTS.find((a) => a.id === achievementIds[index]);
  if (!achievement) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center pointer-events-none">
      <div className="panel animate-slide-in border-yellow-700 bg-[#12100a] px-8 py-6 text-center"
        style={{ boxShadow: "0 0 40px rgba(234,179,8,0.3)" }}>
        <p className="text-xs text-yellow-600 font-mono uppercase tracking-widest mb-2">Achievement Unlocked</p>
        <div className="text-5xl mb-3">{achievement.icon}</div>
        <p className="text-xl font-black text-yellow-400 tracking-widest">{achievement.title}</p>
        <p className="text-xs text-gray-500 mt-1">{achievement.description}</p>
      </div>
    </div>
  );
}
