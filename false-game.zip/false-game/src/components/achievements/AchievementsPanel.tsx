"use client";
import { ACHIEVEMENTS } from "@/lib/achievements";
import type { GameStats } from "@/types";
import { formatDate } from "@/lib/game";

interface Props {
  stats: GameStats;
}

export function AchievementsPanel({ stats }: Props) {
  const unlocked = stats.unlockedAchievements;
  const total = ACHIEVEMENTS.length;
  const pct = Math.round((unlocked.length / total) * 100);

  return (
    <div className="space-y-4">
      {/* Header progress */}
      <div className="panel-red p-4">
        <div className="flex justify-between items-center mb-2">
          <p className="text-xs text-gray-500 uppercase tracking-widest font-mono">Achievements</p>
          <p className="text-lg font-black font-mono text-red-400">{unlocked.length}/{total}</p>
        </div>
        <div className="h-1.5 bg-[#1a1a1a] rounded-full overflow-hidden">
          <div
            className="h-full bg-red-600 rounded-full transition-all duration-700"
            style={{ width: `${pct}%`, boxShadow: "0 0 6px rgba(239,68,68,0.6)" }}
          />
        </div>
      </div>

      {/* Achievement grid */}
      <div className="grid grid-cols-1 gap-2">
        {ACHIEVEMENTS.map((a) => {
          const isUnlocked = unlocked.includes(a.id);
          return (
            <div
              key={a.id}
              className={`panel p-4 flex items-center gap-3 transition-all ${
                isUnlocked
                  ? "border-yellow-900 bg-[#12100a]"
                  : "opacity-40"
              }`}
            >
              <div className={`text-2xl w-10 h-10 flex items-center justify-center rounded border ${
                isUnlocked ? "border-yellow-800 bg-yellow-900/20" : "border-gray-800"
              }`}>
                {isUnlocked ? a.icon : "?"}
              </div>
              <div className="flex-1">
                <p className={`text-sm font-bold font-mono ${isUnlocked ? "text-yellow-400" : "text-gray-600"}`}>
                  {a.title}
                </p>
                <p className="text-xs text-gray-500">{a.description}</p>
              </div>
              {isUnlocked && <span className="text-xs text-yellow-700 font-mono">★</span>}
            </div>
          );
        })}
      </div>
    </div>
  );
}
