"use client";
import { useState, useEffect, useCallback } from "react";
import type { GameState, Task, GameStats } from "@/types";
import {
  getDefaultStats,
  getXPRequired,
  getDifficultyXP,
  getDifficultyPenalty,
  isTaskExpired,
  getRank,
} from "@/lib/game";
import { checkNewAchievements, ACHIEVEMENTS } from "@/lib/achievements";

const STORAGE_KEY = "false-game-state";

function getInitialState(): GameState {
  if (typeof window === "undefined") {
    return { stats: getDefaultStats(), tasks: [] };
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return { stats: getDefaultStats(), tasks: [] };
}

export function useGameState() {
  const [state, setState] = useState<GameState>(() => getInitialState());
  const [newAchievements, setNewAchievements] = useState<string[]>([]);

  // Persist to localStorage on every change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  // Check for expired tasks and apply penalties on mount & every minute
  useEffect(() => {
    function applyPenalties() {
      setState((prev) => {
        const updatedTasks = prev.tasks.map((task) => {
          if (!isTaskExpired(task)) return task;
          return { ...task, penaltyApplied: true };
        });

        const expiredNow = prev.tasks.filter(
          (t) => isTaskExpired(t) && !t.penaltyApplied
        );

        if (expiredNow.length === 0) return { ...prev, tasks: updatedTasks };

        let totalPenalty = 0;
        expiredNow.forEach((t) => {
          totalPenalty += getDifficultyPenalty(t.difficulty);
        });

        const newXP = Math.max(0, prev.stats.currentXP - totalPenalty);
        const newTotalLost = prev.stats.totalXPLost + totalPenalty;
        const newMissed = prev.stats.totalTasksMissed + expiredNow.length;

        return {
          tasks: updatedTasks,
          stats: {
            ...prev.stats,
            currentXP: newXP,
            totalXPLost: newTotalLost,
            totalTasksMissed: newMissed,
          },
        };
      });
    }

    applyPenalties();
    const interval = setInterval(applyPenalties, 60000);
    return () => clearInterval(interval);
  }, []);

  // Update streak daily
  useEffect(() => {
    const today = new Date().toISOString().split("T")[0];
    const last = state.stats.lastActiveDate;
    if (last === today) return;

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yStr = yesterday.toISOString().split("T")[0];

    setState((prev) => {
      const streak = last === yStr ? prev.stats.currentStreak + 1 : 1;
      return {
        ...prev,
        stats: {
          ...prev.stats,
          currentStreak: streak,
          longestStreak: Math.max(prev.stats.longestStreak, streak),
          lastActiveDate: today,
        },
      };
    });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const addXP = useCallback((amount: number, updatedStats?: Partial<GameStats>) => {
    setState((prev) => {
      const newCurrentXP = prev.stats.currentXP + amount;
      const xpRequired = getXPRequired(prev.stats.level);
      let level = prev.stats.level;
      let currentXP = newCurrentXP;
      const levelHistory = [...prev.stats.levelHistory];

      while (currentXP >= getXPRequired(level)) {
        currentXP -= getXPRequired(level);
        level++;
        levelHistory.push({ level, date: new Date().toISOString() });
      }

      const newStats: GameStats = {
        ...prev.stats,
        ...updatedStats,
        level,
        currentXP,
        totalXPEarned: prev.stats.totalXPEarned + amount,
        levelHistory,
      };

      const unlocked = checkNewAchievements(newStats);
      if (unlocked.length > 0) {
        setNewAchievements(unlocked);
        newStats.unlockedAchievements = [...newStats.unlockedAchievements, ...unlocked];
      }

      return { ...prev, stats: newStats };
    });
  }, []);

  const addTask = useCallback((task: Omit<Task, "id" | "createdAt" | "completed">) => {
    const newTask: Task = {
      ...task,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      completed: false,
    };
    setState((prev) => ({ ...prev, tasks: [newTask, ...prev.tasks] }));
  }, []);

  const editTask = useCallback((id: string, updates: Partial<Task>) => {
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) => (t.id === id ? { ...t, ...updates } : t)),
    }));
  }, []);

  const deleteTask = useCallback((id: string) => {
    setState((prev) => ({ ...prev, tasks: prev.tasks.filter((t) => t.id !== id) }));
  }, []);

  const completeTask = useCallback((id: string) => {
    setState((prev) => {
      const task = prev.tasks.find((t) => t.id === id);
      if (!task || task.completed) return prev;

      const xpGain = getDifficultyXP(task.difficulty);
      const updatedTasks = prev.tasks.map((t) =>
        t.id === id ? { ...t, completed: true, completedAt: new Date().toISOString() } : t
      );

      const today = new Date().toISOString().split("T")[0];
      const last = prev.stats.lastActiveDate;
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yStr = yesterday.toISOString().split("T")[0];
      const streak = last === today ? prev.stats.currentStreak : last === yStr ? prev.stats.currentStreak + 1 : 1;

      let newCurrentXP = prev.stats.currentXP + xpGain;
      let level = prev.stats.level;
      const levelHistory = [...prev.stats.levelHistory];
      while (newCurrentXP >= getXPRequired(level)) {
        newCurrentXP -= getXPRequired(level);
        level++;
        levelHistory.push({ level, date: new Date().toISOString() });
      }

      const newStats: GameStats = {
        ...prev.stats,
        level,
        currentXP: newCurrentXP,
        totalXPEarned: prev.stats.totalXPEarned + xpGain,
        totalTasksCompleted: prev.stats.totalTasksCompleted + 1,
        currentStreak: streak,
        longestStreak: Math.max(prev.stats.longestStreak, streak),
        lastActiveDate: today,
        levelHistory,
      };

      const unlocked = checkNewAchievements(newStats);
      if (unlocked.length > 0) {
        setNewAchievements(unlocked);
        newStats.unlockedAchievements = [...newStats.unlockedAchievements, ...unlocked];
      }

      return { tasks: updatedTasks, stats: newStats };
    });
  }, []);

  const resetGame = useCallback(() => {
    const fresh = { stats: getDefaultStats(), tasks: [] };
    setState(fresh);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
  }, []);

  const clearNewAchievements = useCallback(() => setNewAchievements([]), []);

  const activeTasks = state.tasks.filter((t) => !t.completed && !t.penaltyApplied);
  const completedTasks = state.tasks.filter((t) => t.completed);
  const xpRequired = getXPRequired(state.stats.level);
  const rank = getRank(state.stats.level);

  return {
    state,
    stats: state.stats,
    tasks: state.tasks,
    activeTasks,
    completedTasks,
    xpRequired,
    rank,
    newAchievements,
    addTask,
    editTask,
    deleteTask,
    completeTask,
    addXP,
    resetGame,
    clearNewAchievements,
  };
}
