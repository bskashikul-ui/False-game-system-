"use client";
import { useState, useEffect, useRef } from "react";
import { useGameState } from "@/hooks/useGameState";
import { DashboardPanel } from "@/components/dashboard/DashboardPanel";
import { TaskCard } from "@/components/tasks/TaskCard";
import { TaskForm } from "@/components/tasks/TaskForm";
import { StatsPanel } from "@/components/stats/StatsPanel";
import { AchievementsPanel } from "@/components/achievements/AchievementsPanel";
import { AchievementUnlock } from "@/components/achievements/AchievementUnlock";
import { LevelUpOverlay } from "@/components/ui/LevelUpOverlay";
import { FalseGuide } from "@/components/ai/FalseGuide";
import { Nav } from "@/components/ui/Nav";
import { ToastContainer, showToast } from "@/components/ui/Toast";
import type { Task } from "@/types";

type Tab = "dashboard" | "tasks" | "stats" | "achievements" | "guide";

export default function Home() {
  const [tab, setTab] = useState<Tab>("dashboard");
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [taskFilter, setTaskFilter] = useState<"active" | "completed" | "all">("active");
  const [showLevelUp, setShowLevelUp] = useState(false);
  const prevLevelRef = useRef<number | null>(null);

  const {
    stats,
    tasks,
    activeTasks,
    completedTasks,
    xpRequired,
    rank,
    newAchievements,
    addTask,
    editTask,
    deleteTask,
    completeTask,
    clearNewAchievements,
    resetGame,
  } = useGameState();

  // Detect level up
  useEffect(() => {
    if (prevLevelRef.current === null) {
      prevLevelRef.current = stats.level;
      return;
    }
    if (stats.level > prevLevelRef.current) {
      setShowLevelUp(true);
      showToast(`Level Up! You are now Level ${stats.level}`, "levelup");
    }
    prevLevelRef.current = stats.level;
  }, [stats.level]);

  function handleCompleteTask(id: string) {
    const task = tasks.find((t) => t.id === id);
    if (!task) return;
    completeTask(id);
    const xp = task.difficulty === "Easy" ? 25 : task.difficulty === "Medium" ? 50 : task.difficulty === "Hard" ? 100 : 200;
    showToast(`Quest completed! +${xp} XP`, "xp");
  }

  function handleSaveTask(data: Omit<Task, "id" | "createdAt" | "completed">) {
    if (editingTask) {
      editTask(editingTask.id, data);
      showToast("Quest updated.", "info");
    } else {
      addTask(data);
      showToast("New quest created.", "info");
    }
    setEditingTask(null);
  }

  const filteredTasks = taskFilter === "active"
    ? activeTasks
    : taskFilter === "completed"
    ? completedTasks
    : tasks;

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-[#0a0a0a]/95 backdrop-blur border-b border-[#1a1a1a]">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-2 h-2 rounded-full bg-red-500 red-pulse" />
            <span className="text-sm font-black tracking-widest text-white font-mono">FALSE GAME</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-xs text-gray-600 font-mono">LVL {stats.level}</p>
              <p className="text-xs text-red-500 font-mono font-bold">{rank}</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-2xl mx-auto px-4 pt-4 pb-24">
        {tab === "dashboard" && (
          <div className="animate-fade-in">
            <DashboardPanel
              stats={stats}
              activeTasks={activeTasks.length}
              completedTasks={completedTasks.length}
            />
          </div>
        )}

        {tab === "tasks" && (
          <div className="animate-fade-in space-y-4">
            {/* Task controls */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => { setEditingTask(null); setShowTaskForm(true); }}
                className="btn-red"
              >
                + NEW QUEST
              </button>
              <div className="flex border border-[#1f1f1f] rounded overflow-hidden ml-auto">
                {(["active", "completed", "all"] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setTaskFilter(f)}
                    className={`px-3 py-1.5 text-xs font-mono uppercase transition-colors ${
                      taskFilter === f ? "bg-red-900 text-red-400" : "text-gray-600 hover:text-gray-400"
                    }`}
                  >
                    {f === "active" ? `Active (${activeTasks.length})` : f === "completed" ? `Done (${completedTasks.length})` : "All"}
                  </button>
                ))}
              </div>
            </div>

            {/* Task list */}
            {filteredTasks.length === 0 ? (
              <div className="panel p-8 text-center">
                <p className="text-gray-600 font-mono text-sm">
                  {taskFilter === "active" ? "No active quests. Create one to begin." : "No quests here."}
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {filteredTasks.map((task) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    onComplete={handleCompleteTask}
                    onEdit={(t) => { setEditingTask(t); setShowTaskForm(true); }}
                    onDelete={deleteTask}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {tab === "stats" && (
          <div className="animate-fade-in">
            <StatsPanel stats={stats} tasks={tasks} />
          </div>
        )}

        {tab === "achievements" && (
          <div className="animate-fade-in">
            <AchievementsPanel stats={stats} />
          </div>
        )}

        {tab === "guide" && (
          <div className="animate-fade-in h-full">
            <FalseGuide stats={stats} tasks={tasks} />
          </div>
        )}

        {/* Dev reset button — small and tucked away */}
        {tab === "dashboard" && (
          <div className="mt-8 text-center">
            <button
              onClick={() => {
                if (confirm("Reset all game data? This cannot be undone.")) {
                  resetGame();
                  showToast("System reset.", "info");
                }
              }}
              className="text-xs text-gray-800 hover:text-gray-600 font-mono transition-colors"
            >
              reset system
            </button>
          </div>
        )}
      </main>

      {/* Navigation */}
      <Nav active={tab} onChange={setTab} />

      {/* Modals & Overlays */}
      {showTaskForm && (
        <TaskForm
          task={editingTask}
          onSave={handleSaveTask}
          onClose={() => { setShowTaskForm(false); setEditingTask(null); }}
        />
      )}

      {newAchievements.length > 0 && (
        <AchievementUnlock
          achievementIds={newAchievements}
          onDismiss={clearNewAchievements}
        />
      )}

      {showLevelUp && (
        <LevelUpOverlay
          level={stats.level}
          prevLevel={stats.level - 1}
          onDone={() => setShowLevelUp(false)}
        />
      )}

      <ToastContainer />
    </div>
  );
}
