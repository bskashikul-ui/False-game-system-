export type Difficulty = "Easy" | "Medium" | "Hard" | "Extreme";
export type Rank = "UNEVOLVED" | "EVOLVER" | "PHANTOM" | "DEMI ELITE" | "ELITE";

export interface Task {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  dueTime: string; // ISO string
  difficulty: Difficulty;
  completed: boolean;
  completedAt?: string;
  createdAt: string;
  penaltyApplied?: boolean;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt?: string;
  condition: (stats: GameStats) => boolean;
}

export interface GameStats {
  level: number;
  currentXP: number;
  totalXPEarned: number;
  totalXPLost: number;
  currentStreak: number;
  longestStreak: number;
  totalTasksCompleted: number;
  totalTasksMissed: number;
  lastActiveDate: string;
  levelHistory: { level: number; date: string }[];
  unlockedAchievements: string[];
}

export interface GameState {
  stats: GameStats;
  tasks: Task[];
}

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}
