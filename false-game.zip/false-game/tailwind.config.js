/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        bg: "#0a0a0a",
        panel: "#111111",
        border: "#1f1f1f",
        surface: "#161616",
        red: {
          400: "#f87171",
          500: "#ef4444",
          600: "#dc2626",
          700: "#b91c1c",
          900: "#450a0a",
        },
      },
      fontFamily: {
        mono: ["'Courier New'", "Courier", "monospace"],
        sans: ["system-ui", "sans-serif"],
      },
      animation: {
        "pulse-red": "pulse-red 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "glow": "glow 2s ease-in-out infinite alternate",
        "slide-in": "slide-in 0.3s ease-out",
        "fade-in": "fade-in 0.4s ease-out",
      },
      keyframes: {
        "pulse-red": {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.5" },
        },
        "glow": {
          "from": { boxShadow: "0 0 5px #ef4444, 0 0 10px #ef4444" },
          "to": { boxShadow: "0 0 10px #ef4444, 0 0 20px #ef4444, 0 0 30px #ef4444" },
        },
        "slide-in": {
          "from": { transform: "translateY(-10px)", opacity: "0" },
          "to": { transform: "translateY(0)", opacity: "1" },
        },
        "fade-in": {
          "from": { opacity: "0" },
          "to": { opacity: "1" },
        },
      },
      boxShadow: {
        "red-glow": "0 0 15px rgba(239, 68, 68, 0.4)",
        "red-glow-lg": "0 0 30px rgba(239, 68, 68, 0.5)",
        "panel": "0 4px 24px rgba(0,0,0,0.8)",
      },
    },
  },
  plugins: [],
};
